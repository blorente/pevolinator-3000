package model.population.tree;

public enum TreeCreationMethods {
	INCREMENTAL,
	COMPLETE,
	RAMP_AND_HALF,
	WEIGHED
}
