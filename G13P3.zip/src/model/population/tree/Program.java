package model.population.tree;

import java.util.Map;

public class Program {
	private Node root;
	
	
}
